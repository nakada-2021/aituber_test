
# AITuber Test

## 概要

- iPadブラウザからカメラ映像取得
- MediaPipeで表情・ポーズを解析し、キーポイントのみを送信
- LLM（ChatGPTなど）と連携して返答・制御
- Unity WebGLでLive2D表示

## 構成

- frontend/ ：ブラウザUI＋MediaPipe
- backend/ ：WebSocketサーバー＋LLM連携
- unity_webgl/ ：Live2Dモデル表示用WebGLテンプレート
- tools/live2d_auto_generator.py ：Live2D自動生成スクリプト

## Live2D自動生成ツール

`tools/live2d_auto_generator.py` を使うと、以下が可能です。

- 髪型・表情・服装をプロンプトで指定
- AI画像生成＋パーツ分けPNG出力

### 使い方

```bash
python tools/live2d_auto_generator.py --prompt "赤髪 ショート ボーイッシュ 女の子"
```

出力：

- output/hair.png
- output/face.png
- output/body.png

